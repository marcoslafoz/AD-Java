package ejercicio1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GestorVideojuegos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Videojuego> videojuegos;
        
        try {
        	videojuegos = AccesoVideojuegoTexto.leerTodos();
            
        } catch (IOException e) {
            System.err.println("Error al cargar los videojuegos: " + e.getMessage());
            videojuegos = new ArrayList<>();
        }

        int opcion = 1;
        while (opcion != 0){
            System.out.println("Menú de opciones:");
            System.out.println("0) Salir del programa.");
            System.out.println("1) Crear un fichero binario a partir del fichero de texto.");
            System.out.println("2) Eliminar un videojuego por codigo del fichero binario.");
            System.out.println("3) Actualizar un videojuego por codigo del fichero de texto.");
            System.out.print("Elija una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la línea en blanco

            switch (opcion) {
                case 1:
                	AccesoVideojuegoBinario.escribirTodos(videojuegos);
                    break;
                case 2:
                	eliminarVideojuego(videojuegos, scanner);
                	AccesoVideojuegoBinario.escribirTodos(videojuegos);
                    break;
                case 3:
                	actualizarVideojuego(videojuegos, scanner);
                    break;
                case 0:
                    System.out.println("Saliendo del programa.");
                    break;
                default:
                    System.out.println("La opción de menú debe estar comprendida entre 0 y 3.");
            }
        }

        try {
            AccesoVideojuegoTexto.escribirTodos(videojuegos);
        } catch (IOException e) {
            System.err.println("Error al guardar los videjuegos: " + e.getMessage());
        }
    }	

    private static void actualizarVideojuego(List<Videojuego> videojuegos, Scanner scanner) {
        System.out.println("Actualizar un videojuego por código:");

        System.out.print("Introduce el código del videojuego a actualizar: ");
        int codigoVideojuego = scanner.nextInt();

        boolean encontrado = false;
        for (Videojuego videojuego : videojuegos) {
            if (videojuego.getCodigo() == codigoVideojuego) {
                
            	 System.out.println("Introduce los nuevos datos del videojuego:");

                 System.out.print("Titulo: ");
                 scanner.nextLine();
                 scanner.nextLine(); // Consumir la línea en blanco

                 System.out.print("Titulo: ");
                 String titulo= scanner.nextLine();
                 
                 System.out.print("Plataforma: ");
                 String plataforma = scanner.nextLine();

                 System.out.print("Precio: ");
                 double precio = scanner.nextDouble();
                
                videojuego.setPlataforma(plataforma);
                videojuego.setTitulo(titulo);
                videojuego.setPrecio(precio);

                System.out.println("Se ha actualizado un videojuego del fichero de texto.");
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            System.out.println("No existe ningún videojuego con ese código en el fichero de texto.");
        }
    }
    
    
    private static void eliminarVideojuego(List<Videojuego> videojuegos, Scanner scanner) {
        System.out.print("Código del videojuego a eliminar: ");
        int codigo = scanner.nextInt();
        scanner.nextLine();

        Videojuego videojuegoExistente = null;
        for (Videojuego v : videojuegos) {
            if (v.getCodigo() == codigo) {
            	videojuegoExistente = v;
                break;
            }
        }

        if (videojuegoExistente == null) {
            System.out.println("No existe ningún videojuego con ese código en el fichero binario.");
        } else {
        	videojuegos.remove(videojuegoExistente);
            System.out.println("Se ha eliminado un videojuego del fichero binario.");
        }
    }


    
}
