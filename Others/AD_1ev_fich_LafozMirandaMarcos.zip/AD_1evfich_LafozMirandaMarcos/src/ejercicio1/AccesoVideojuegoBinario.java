package ejercicio1;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class AccesoVideojuegoBinario {
    private static final String FILENAME = "data/videojuegos_sec.dat";

    public static List<Videojuego> leerTodos() {
        List<Videojuego> videojuegos = new ArrayList<>();

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILENAME))) {
            while (true) {
                Videojuego videojuego = (Videojuego) ois.readObject();
                videojuegos.add(videojuego);
            }
        } catch (EOFException e) {
            return videojuegos;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return videojuegos;
        }
    }

    public static void escribirTodos(List<Videojuego> videojuegos) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILENAME))) {
            for (Videojuego videojuego : videojuegos) {
                oos.writeObject(videojuego);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
	