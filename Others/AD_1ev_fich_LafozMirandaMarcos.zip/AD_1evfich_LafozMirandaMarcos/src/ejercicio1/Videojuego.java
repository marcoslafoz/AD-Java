package ejercicio1;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.List;

public class Videojuego implements Serializable {
    private int codigo;
    private String titulo;
    private String plataforma;
    private double precio;	

    public Videojuego(int codigo, String titulo, String plataforma, double precio) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.plataforma = plataforma;
        this.precio = precio;
    }
	
    public Videojuego(String linea) {
        String[] partes = linea.split(";");
        this.codigo = Integer.parseInt(partes[0]);
        this.titulo = partes[1];
        this.plataforma = partes[2];

        try {
            this.precio = new DecimalFormat("#,##0.00").parse(partes[3]).doubleValue();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    
    @Override
    public String toString() {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        return "Videojuego [Código = " + codigo + ", Titulo = " + titulo + ", Plataforma = " + plataforma + ", Precio = " + df.format(precio) + " €]";
    }

    public String toStringWithSeparators() {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        return codigo + ";" + titulo + ";" + plataforma + ";" + df.format(precio).replace(",", ".");
    }
    
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getPlataforma() {
		return plataforma;
	}

	public void setPlataforma(String plataforma) {
		this.plataforma = plataforma;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
}
	