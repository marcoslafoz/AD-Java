package ejercicio1;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class AccesoVideojuegoTexto {
    private static final String FILENAME = "data/videojuegos_sec.txt";

    static File archivo = new File(FILENAME);
    
    public static List<Videojuego> leerTodos() throws IOException {
        List<Videojuego> videojuegos = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            String line;
            while ((line = reader.readLine()) != null) {
            	videojuegos.add(new Videojuego(line));
            }
        }
        return videojuegos;
    }

    public static void escribirTodos(List<Videojuego> listaVideojuegos) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) {
            for (Videojuego v : listaVideojuegos) {
                writer.write(v.toStringWithSeparators());
                writer.newLine();
            }
        }
    }
}
	