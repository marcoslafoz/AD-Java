package examen;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.result.DeleteResult;
import static com.mongodb.client.model.Sorts.ascending;
import static com.mongodb.client.model.Sorts.descending;
import static com.mongodb.client.model.Filters.eq;

public class AccesoPersonal {

	///////////////// MOSTRAR MENU //////////////////
	public static String mostrarMenu() {
		return "\r\n(0) Salir del programa.\r\n" + "(1) Consultar todos los empleados ordenados por salario desc.\r\n"
				+ "(2) Insertar un empleado.\r\n" + "(3) Eliminar un empleado.\r\n";
	}

	//////////////////// CONSULTAR TODOS ORDENADOS //////////////////////
	public static List<Empleado> consultarTodos() throws Exception {

		MongoClient cliente = null;
		List<Document> resultadosDoc = null;
		List<Empleado> resultados = new ArrayList<>();

		try {
			cliente = new MongoClient();
			MongoDatabase bd = cliente.getDatabase(ConfigDB.DB_NAME);
			MongoCollection<Document> collection = bd.getCollection(ConfigDB.COLLECTION_NAME_1);
			resultadosDoc = collection.find().sort(ascending("salario")).into(new ArrayList<Document>());

			for (Document d : resultadosDoc) {
				resultados.add(new Empleado(d.getInteger("codigo"), d.getString("nombre"), d.getString("fecha_alta"),
						d.getString("departamento"), d.getDouble("salario")));
			}

		} finally {
			if (cliente != null) {
				cliente.close();
			}
		}

		return resultados;

	}

	//////////////////// CONSULTAR CODIGO M�XIMO //////////////////////
	public static int consultarCodigoMaximo() throws Exception {
		MongoClient cliente = null;
		int codigoMaximo = 0;

		try {
			cliente = new MongoClient();
			MongoDatabase bd = cliente.getDatabase(ConfigDB.DB_NAME);
			MongoCollection<Document> collection = bd.getCollection(ConfigDB.COLLECTION_NAME_1);

			Document maxCodigoDoc = collection.find().sort(descending("codigo")).first();
			if (maxCodigoDoc != null) {
				codigoMaximo = maxCodigoDoc.getInteger("codigo");
			}

		} finally {
			if (cliente != null) {
				cliente.close();
			}
		}

		return codigoMaximo;
	}

	//////////////////// INSERTAR UNO //////////////////////
	public static boolean insertarElemento(Empleado elementoInsertar) throws Exception {
		boolean esInsertado = false;
		MongoClient cliente = null;

		try {
			cliente = new MongoClient();
			MongoDatabase bd = cliente.getDatabase(ConfigDB.DB_NAME);
			MongoCollection<Document> collection = bd.getCollection(ConfigDB.COLLECTION_NAME_1);

			Document elementoDoc = new Document();
			elementoDoc.put("codigo", consultarCodigoMaximo() + 1);
			elementoDoc.put("nombre", elementoInsertar.getNombre());
			elementoDoc.put("fecha_alta", elementoInsertar.getNombre());
			elementoDoc.put("salario", elementoInsertar.getSalario());
			elementoDoc.put("departamento", elementoInsertar.getDepartamento());

			collection.insertOne(elementoDoc);
			esInsertado = true;

		} finally {
			if (cliente != null) {
				cliente.close();
			}
		}

		return esInsertado;
	}

	//////////////////// CONSULTAR EMPLEADO POR CODIGO //////////////////////
	public static Empleado consultarElementoPorCodigo(int codigo) throws Exception {
		Empleado elemento = null;
		MongoClient cliente = null;

		try {
			cliente = new MongoClient();
			MongoDatabase bd = cliente.getDatabase(ConfigDB.DB_NAME);
			MongoCollection<Document> collection = bd.getCollection(ConfigDB.COLLECTION_NAME_1);

			Document elementoDoc = collection.find(eq("codigo", codigo)).first();

			if (elementoDoc != null) {
				elemento = new Empleado(elementoDoc.getInteger("codigo"), elementoDoc.getString("nombre"),
						elementoDoc.getString("fecha_alta"), elementoDoc.getString("departamento"),
						elementoDoc.getDouble("salario"));
			}
		} finally {
			if (cliente != null) {
				cliente.close();
			}
		}

		return elemento;
	}

	//////////////////// ELIMINAR EMPLEADO POR CODIGO //////////////////////
	public static boolean eliminarElementoPorCodigo(int codigo) throws Exception {

		boolean elementoEliminado = false;
		MongoClient cliente = null;

		try {
			cliente = new MongoClient();
			MongoDatabase bd = cliente.getDatabase(ConfigDB.DB_NAME);
			MongoCollection<Document> collection = bd.getCollection(ConfigDB.COLLECTION_NAME_1);

			DeleteResult resultado = collection.deleteOne(eq("codigo", codigo));

			if (resultado.getDeletedCount() > 0) {
				elementoEliminado = true;
			}

		} finally {
			if (cliente != null) {
				cliente.close();
			}
		}

		return elementoEliminado;
	}

}
