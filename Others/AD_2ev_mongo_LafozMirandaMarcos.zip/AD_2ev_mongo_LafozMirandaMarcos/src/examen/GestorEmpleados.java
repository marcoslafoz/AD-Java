package examen;

import java.util.List;
import entrada.Teclado;

public class GestorEmpleados {
	public static void main(String[] args) {

		try {
			int opcion = -1;

			while (opcion != 0) {
				System.out.println(AccesoPersonal.mostrarMenu());
				opcion = Teclado.leerEntero("Introduce una opci�n: ");

				switch (opcion) {
				case 0:

					System.out.println("Saliendo del programa.");
					break;

				///////////////// CONSULTAR TODOS LOS EMPLEADOS ORDENADOS //////////////////
				case 1:

					List<Empleado> resultadosConsultarTodos = AccesoPersonal.consultarTodos();

					if (resultadosConsultarTodos.isEmpty()) {
						System.out.println("La BD no tiene ningun empleado.");
					} else {

						for (Empleado e : resultadosConsultarTodos) {
							System.out.println(e.toString());
						}

						System.out.println("Se han consultado " + resultadosConsultarTodos.size() + " empleados en la BD.");
					}

					break;

				///////////////// INSERTAR EMPLEADO //////////////////
				case 2:

					Empleado elementoInsertar = new Empleado(0, Teclado.leerCadena("Nombre: "),
							Teclado.leerCadena("Fecha alta: "), Teclado.leerCadena("Departamento: "),
							Teclado.leerReal("Salario: "));

					boolean elementoInsertartado = AccesoPersonal.insertarElemento(elementoInsertar);

					if (elementoInsertartado == true) {
						System.out.println("Se ha insertado un empleado en la BD");
					} else {
						System.out.println("Empleado no insertado");
					}

					break;

				///////////////// ELIMINAR EMPLEADO //////////////////
				case 3:

					int codigoEmpleadoEliminar = Teclado.leerEntero("Codigo de empleado a eliminar: ");

					if (AccesoPersonal.consultarElementoPorCodigo(codigoEmpleadoEliminar) != null) {

						if (AccesoPersonal.eliminarElementoPorCodigo(codigoEmpleadoEliminar)) {
							System.out.println("Se ha eliminado un empleado de la BD");
						} else {
							System.out.println("Error al eliminar el empleado");
						}

					} else {
						System.out.println("No se ha encontrado ningun empleado con ese c�digo en la BD");
					}

					break;

				default:
					System.out.println("\nOpcion inv�lida.");
					break;

				}
			}
		} catch (Exception e) {
			System.out.println("Error al acceder a la base de datos");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

	}
}
