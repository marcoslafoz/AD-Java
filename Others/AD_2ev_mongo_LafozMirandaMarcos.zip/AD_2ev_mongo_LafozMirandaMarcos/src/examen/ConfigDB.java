package examen;

public class ConfigDB {

	public static final String DB_NAME = "empleados";
	public static final String COLLECTION_NAME_1 = "empleados";

}
