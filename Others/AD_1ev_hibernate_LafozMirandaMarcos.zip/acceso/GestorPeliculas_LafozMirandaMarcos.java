package acceso;

import java.math.BigDecimal;
import java.util.List;
import org.hibernate.HibernateException;
import entrada.Teclado;
import modelo.Pelicula;
import modelo.Director;

public class GestorPeliculas_LafozMirandaMarcos {
	// Escribe en consola el men� de opciones del programa principal.
	public static void escribirMenuOpciones() {
		System.out.println();
		System.out.println("(0) Salir del programa.");
		System.out.println("(1) Mostrar todas las peliculas ordenadas por año (desc).");
		System.out.println("(2) Insertar Pelicula ");
		System.out.println("(3) Eliminar director ");
		System.out.println();
	}

	public static void main(String[] args) {
		int opcion;

		do {
			escribirMenuOpciones();
			opcion = Teclado.leerEntero("�Opci�n (0-5)? ");
			try {
				switch (opcion) {
				// Salir del programa.
				case 0:
					break;

				case 1:

					List<Pelicula> listaPeliculas = AccesoFilmoteca_LafozMirandaMarcos.consultarPeliculas();

					if (listaPeliculas.size() == 0) {
						System.out.println("La base de datos no tiene ninguna pelicula.");
					} else {
						for (Pelicula pelicula : listaPeliculas) {
							System.out.println(pelicula.toString());
						}
						System.out.println(
								"Se han consultado " + listaPeliculas.size() + " peliculas de la base de datos.");
					}

					break;

				case 2:
					AccesoFilmoteca_LafozMirandaMarcos.insertarPelicula();
					break;
				case 3:

					AccesoFilmoteca_LafozMirandaMarcos
							.eliminarDirector(Teclado.leerEntero("Introduce el codigo del director a eliminar:"));
					break;

				default:
					System.out.println("La opci�n de men� debe estar comprendida entre 0 y 3.");
				}
			} catch (HibernateException he) {
				System.out.println("Error al acceder a la base de datos MySQL con Hibernate:");
				System.out.println(he.getMessage());
			}
		} while (opcion != 0);
		HibernateUtil.closeSessionFactory();
		System.out.println("Programa finalizado sin errores.");
	}

}
