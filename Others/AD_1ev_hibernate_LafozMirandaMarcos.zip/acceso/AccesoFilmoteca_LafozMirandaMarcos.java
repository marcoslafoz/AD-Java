package acceso;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import modelo.Director;
import modelo.Pelicula;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.TypedQuery;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import entrada.Teclado;

public class AccesoFilmoteca_LafozMirandaMarcos {

	// Metodo consultar peliculas ordenadas
	public static List<Pelicula> consultarPeliculas() throws HibernateException {

		Session sesion = null;

		List<Pelicula> listaPeliculas = new ArrayList<Pelicula>();

		try {
			SessionFactory fabricaSesiones = HibernateUtil.getSessionFactory();
			sesion = fabricaSesiones.openSession();
			String sentenciaHQL = "select p from Pelicula p order by p.agnoEstreno desc";
			Query consulta = sesion.createQuery(sentenciaHQL);
			listaPeliculas = consulta.list();
			return listaPeliculas;
		} finally {
			if (sesion != null) {
				sesion.close();
			}
		}

	}

	// Metodo consultar directores
	public static void consultarDirectores() throws HibernateException {

		Session sesion = null;

		List<Director> listaDirectores = new ArrayList<Director>();

		try {
			SessionFactory fabricaSesiones = HibernateUtil.getSessionFactory();
			sesion = fabricaSesiones.openSession();
			String sentenciaHQL = "select d from Director d";
			Query consulta = sesion.createQuery(sentenciaHQL);
			listaDirectores = consulta.list();

			if (listaDirectores.size() == 0) {
				System.out.println("La base de datos no tiene ningun director.");
			} else {
				for (Director director : listaDirectores) {
					System.out.println(director.toString());
				}
				System.out.println("Se han consultado " + listaDirectores.size() + " directores de la base de datos.");
			}

		} finally {
			if (sesion != null) {
				sesion.close();
			}
		}

	}

	public static Director consultarDirector(int codigo) throws HibernateException {

		Director director = null;
		Session sesion = null;

		try {
			SessionFactory fabricaSesiones = HibernateUtil.getSessionFactory();
			sesion = fabricaSesiones.openSession();

			director = sesion.get(Director.class, (Integer) codigo);

		} finally {
			if (sesion != null) {
				sesion.close();
			}
		}
		return director;

	}

	public static void insertarUnaPelicula(Pelicula pelicula) throws HibernateException {
		Session sesion = null;
		Transaction transaccion = null;
		try {

			SessionFactory fabricaSesiones = HibernateUtil.getSessionFactory();
			sesion = fabricaSesiones.openSession();
			transaccion = sesion.beginTransaction();

			sesion.save(pelicula);
			transaccion.commit();
			System.out.println("Se ha insertado un pelicula en la base de datos.");
		}

		finally {
			if (sesion != null) {
				sesion.close();
			}
		}
	}

	public static boolean insertarPelicula() throws HibernateException {

		boolean peliculaInsertada = false;

		consultarDirectores();

		int directorConsultar = Teclado.leerEntero("Introduce el codigo del director a consultar");

		Director directorCons;
		Pelicula peliculaInsertar = new Pelicula();

		directorCons = consultarDirector(directorConsultar);

		if (directorCons != null) {
			System.out.println(directorCons.toString());
			// titulo, año, puntu, cod direc

			peliculaInsertar.setTitulo(Teclado.leerCadena("Introduce el titulo:"));
			peliculaInsertar.setAgnoEstreno(Teclado.leerEntero("Introduce año de estreno:"));
			peliculaInsertar.setPuntuacion(BigDecimal.valueOf(Teclado.leerReal("Introduce puntuación:")));
			peliculaInsertar.setDirector(directorCons);
			peliculaInsertar.setCodigo(null);
			insertarUnaPelicula(peliculaInsertar);

		} else {
			System.out.println("No existe ningun director con ese codigo en la bbdd");
		}

		return peliculaInsertada;

	}

	// Metodo consultar peliculas ordenadas
	public static List<Pelicula> consultarPeliculasPorDirector(int codigoDirector) throws HibernateException {

		Session sesion = null;

		List<Pelicula> listaPeliculas = new ArrayList<Pelicula>();
		List<Pelicula> listaPeliculasAsignadas = new ArrayList<Pelicula>();

		try {
			SessionFactory fabricaSesiones = HibernateUtil.getSessionFactory();
			sesion = fabricaSesiones.openSession();
			String sentenciaHQL = "select p from Pelicula p";
			Query consulta = sesion.createQuery(sentenciaHQL);
			listaPeliculas = consulta.list();

			if (listaPeliculas.size() == 0) {
				System.out.println("La base de datos no tiene ninguna pelicula.");
			} else {
				for (Pelicula pelicula : listaPeliculas) {
					if (pelicula.getDirector().getCodigo() == codigoDirector) {
						listaPeliculasAsignadas.add(pelicula);
						System.out.println(pelicula.toString());
					}
				}
				System.out.println(
						"Se han consultado " + listaPeliculasAsignadas.size() + " peliculas de la base de datos.");
			}

			return listaPeliculasAsignadas;

		} finally {
			if (sesion != null) {
				sesion.close();
			}
		}

	}

	public static void eliminarDirector(int codigoDirector) throws HibernateException {

		List<Pelicula> listaPeliculasAsignadas = consultarPeliculasPorDirector(codigoDirector);
		boolean eliminado;

		Director director = consultarDirector(codigoDirector);

		if (director != null) {
			// Aqui eliminara el director
			if (listaPeliculasAsignadas.size() <= 0) {

				eliminado = eliminarUnDirector(codigoDirector);
				// Si se ha eliminado saltara este mensaje
				if (eliminado == true) {
					System.out.println("Se ha eliminado un director de la base de datos");
				}
			} else {
				System.out.println("Se han encontrado " + listaPeliculasAsignadas.size()
						+ " peliculas referenciadas a ese director");
			}
		} else {
			System.out.println("No existe ningun director cib ese código en la base de datos");
		}

	}

	public static boolean eliminarUnDirector(int codigo) throws HibernateException {

		boolean eliminado = false;
		Director director;
		Session sesion = null;
		Transaction transaccion = null;
		try {

			SessionFactory fabricaSesiones = HibernateUtil.getSessionFactory();
			sesion = fabricaSesiones.openSession();
			transaccion = sesion.beginTransaction();
			director = sesion.get(Director.class, (int) codigo);
			if (director != null) {
				sesion.delete(director);
				transaccion.commit();
				eliminado = true;

			}
		} catch (Exception e) {
			if (transaccion != null) {
				transaccion.rollback();
			}
		} finally {
			if (sesion != null) {
				sesion.close();

			}
		}
		return eliminado;
	}
}
