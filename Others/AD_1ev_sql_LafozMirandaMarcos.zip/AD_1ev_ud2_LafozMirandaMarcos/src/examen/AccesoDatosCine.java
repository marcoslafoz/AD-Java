package examen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AccesoDatosCine {

	// Metodo para añadir salas desde una lista
	public static void insertarSalas() throws SQLException {
		try (Connection connection = DriverManager.getConnection("jdbc:sqlite:db/salas_de_cine.db")) {
			int salasAnadidas = 0;

			connection.setAutoCommit(false);

			// Creamos lista se salas predefinida
			List<Sala> listaSalas = new ArrayList<>();

			Sala sala1 = new Sala(10, "uno", 90, 3, 2.5);
			Sala sala2 = new Sala(11, "dos", 125, 4.5, 4);
			Sala sala3 = new Sala(12, "tres", 250, 5.75, 5.25);
			Sala sala4 = new Sala(13, "cuatro", 400, 7.9, 7.4);

			listaSalas.add(sala1);
			listaSalas.add(sala2);
			listaSalas.add(sala3);
			listaSalas.add(sala4);

			String sql = "INSERT INTO sala (nombre, numero_butacas, precio_normal, precio_reducido) "
					+ "VALUES (?, ?, ?, ?)";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);

			try {

				for (Sala s : listaSalas) {
					//System.out.println(s.toString());
					preparedStatement.setString(1, s.getNombre());
					preparedStatement.setInt(2, s.getNumeroButacas());
					preparedStatement.setDouble(3, s.getPrecioNormal());
					preparedStatement.setDouble(4, s.getPrecioReducido());
					preparedStatement.executeUpdate();
					salasAnadidas++;
				}
				
			} finally {
				System.out.println("Se han insertado " + salasAnadidas + " salas en la bd");
				preparedStatement.close();
			}

			// Confirmar los cambios en la base de datos
			connection.commit();
		}
	}

	// Metodo para listar todas las peliculas
	public static List<Pelicula> listarPeliculas() throws ClassNotFoundException, SQLException {
		List<Pelicula> listaPeliculas = new ArrayList<>();
		Connection conexion = null;
		try {
			// Configuración de la conexión a la base de datos SQLite
			Class.forName("org.sqlite.JDBC");
			conexion = DriverManager.getConnection("jdbc:sqlite:db/salas_de_cine.db");

			// Consulta SQL para seleccionar todos las peliculas
			String sentenciaConsultar = "SELECT * FROM pelicula";
			Statement sentencia = conexion.createStatement();
			ResultSet resultados = sentencia.executeQuery(sentenciaConsultar);

			// Recorrer los resultados y crear objetos Pelicula
			while (resultados.next()) {
				Sala sala = new Sala(resultados.getInt("duracion"), "Sala " + resultados.getInt("duracion"), 0, 0, 0);

				Pelicula pelicula = new Pelicula(resultados.getInt("codigo"), resultados.getString("titulo"),
						resultados.getString("sinopsis"), resultados.getInt("duracion"),
						resultados.getString("fecha_estreno"), sala);
				listaPeliculas.add(pelicula);
			}

			// Cerrar recursos
			resultados.close();
			sentencia.close();
		} finally {
			// Cerrar la conexión a la base de datos
			if (conexion != null) {
				conexion.close();
			}
		}

		return listaPeliculas;
	}

}
