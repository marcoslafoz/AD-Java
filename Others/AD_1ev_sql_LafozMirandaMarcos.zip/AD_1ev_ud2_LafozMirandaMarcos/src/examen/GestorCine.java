package examen;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import entrada.Teclado;

public class GestorCine {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		boolean menu = true;
		while (menu) {
			imprimirMenu();
			int opcion = Teclado.leerEntero("Introduce tu opcion: ");
			switch (opcion) {
			case 0:
				menu = false;
				System.out.println("Saliendo");
				break;
			case 1:
				AccesoDatosCine.insertarSalas();
				break;

			case 2:
				// Opcion 2
				break;
			case 3:
				listarPeliculas();
				break;

			default:
				System.out.println("Opcion no valida");
				break;
			}
		}
	}

	public static void imprimirMenu() {
		System.out.println("0 - Salir del programa");
		System.out.println("1 - Insertar salas desde una coleccion con sentencia preparada");
		System.out.println("2 - Eliminar una presentacion mediante");
		System.out.println("3 - Consultar todas las peliculas");
	}

	public static void listarPeliculas() throws ClassNotFoundException, SQLException {
		List<Pelicula> listaPeliculas = new ArrayList<>();
		listaPeliculas = AccesoDatosCine.listarPeliculas();
		for (Pelicula d : listaPeliculas) {
			System.out.println(d.toString());
		}
		if (listaPeliculas.size() == 0) {
			System.out.println("No se ha encontrado ning�n pelicula en la base de datos.");
		} else {
			System.out.println("Se han consultado " + listaPeliculas.size() + " peliculas de la base de datos.");
		}

	}

}
