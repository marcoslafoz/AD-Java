/**
 * 
 */
/**
 * 
 */
module EjerciciosAD {
	requires java.sql;
	requires teclado;
	requires org.xerial.sqlitejdbc;
}