package examen;

import java.util.List;

import entrada.Teclado;
import modelo.Libro;
import modelo.Prestamo;
import modelo.Socio;
import utils.Herramientas;

public class GestorBiblioteca {
	public static void main(String[] args) {

		try {
			int opcion = -1;

			while (opcion != 0) {
				Herramientas.mostrarMenu();
				opcion = Teclado.leerEntero("Introduce una opci�n: ");

				switch (opcion) {
				case 0:

					System.out.println("Saliendo del programa.");
					break;

				///////////////// CONSULTAR TODOS LOS LIBROS //////////////////
				case 1:

					List<Libro> listaLibrosConsultar = AccesoBiblioteca.consultarProductos();

					if (listaLibrosConsultar.size() > 0) {
						for (Libro l : listaLibrosConsultar) {
							System.out.println(l.toString());
						}
						System.out.println(
								"Se han consultado " + listaLibrosConsultar.size() + " libros de la base de datos");
					} else {
						System.out.println("La base de datos no tiene ning�n libro");
					}

					AccesoBiblioteca.consultarProductos();

					break;

				///////////////// INSERTAR SOCIO //////////////////
				case 2:

					String dniSocioInsertar = Teclado.leerCadena("Introduce el DNI del socio a consultar");

					Socio socioInsertar = AccesoBiblioteca.consultarSocioPorDNI(dniSocioInsertar);

					if (socioInsertar != null) {
						System.out.println("Se ha encontrado un socio con ese DNI en la base de datos");
					} else {
						String nombreSocioInsertar = Teclado.leerCadena("Nombre? ");
						String localidadSocioInsertar = Teclado.leerCadena("Localidad? ");
						String telefonoSocioInsertar = Teclado.leerCadena("Telefono? ");
						String correoSocioInsertar = Teclado.leerCadena("Correo? ");

						boolean socioInsertado = AccesoBiblioteca.insertarSocio(dniSocioInsertar, nombreSocioInsertar,
								localidadSocioInsertar, telefonoSocioInsertar, correoSocioInsertar);

						if (socioInsertado) {
							System.out.println("Socio insertado correctamente");
						} else {
							System.out.println("Error al insertar el socio");
						}

					}

					break;

				///////////////// ELIMINAR SOCIO //////////////////
				case 3:

					String dniSocioEliminar = Teclado.leerCadena("DNI de socio a eliminar: ");

					List<Prestamo> listaPrestamosDeSocioEliminar = AccesoBiblioteca
							.consultarPrestamosPorDNI(dniSocioEliminar);

					if (listaPrestamosDeSocioEliminar.size() > 0) {
						System.out.println("Se han encontrado " + listaPrestamosDeSocioEliminar.size()
								+ " pr�stamos relacionados");
						for (Prestamo p : listaPrestamosDeSocioEliminar) {
							System.out.println(p.toString());
						}

					} else if (listaPrestamosDeSocioEliminar.size() == 0) {

						boolean socioEliminado = AccesoBiblioteca.eliminarSocio(dniSocioEliminar);

						if (socioEliminado) {
							System.out.println("Se ha eliminado un socio de la base de datos");
						} else {
							System.out.println("No se ha encontrado ningun socio con ese DNI en la base de datos");
						}

					}

					break;

				//////////////////// DEFAULT //////////////////////
				default:
					System.out.println("\nOpcion inv�lida.");
					break;

				}
			}
		} catch (Exception e) {
			System.out.println("Error al acceder a la base de datos eXist-db:");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

	}
}
