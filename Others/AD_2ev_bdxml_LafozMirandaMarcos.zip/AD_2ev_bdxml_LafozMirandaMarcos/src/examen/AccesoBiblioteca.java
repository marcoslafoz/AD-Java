package examen;

import java.util.ArrayList;
import java.util.List;

import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Database;
import org.xmldb.api.base.Resource;
import org.xmldb.api.base.ResourceIterator;
import org.xmldb.api.base.ResourceSet;
import org.xmldb.api.base.XMLDBException;
import org.xmldb.api.modules.XPathQueryService;
import modelo.Libro;
import modelo.Prestamo;
import modelo.Socio;
import utils.ConfigDB;

public class AccesoBiblioteca {

	//////////////////// CONECTAR //////////////////////
	private static Collection conectar()
			throws ClassNotFoundException, IllegalAccessException, InstantiationException, XMLDBException {
		Class cl = Class.forName(ConfigDB.EXIST_DRIVER);
		Database database = (Database) cl.newInstance();
		DatabaseManager.registerDatabase(database);
		return DatabaseManager.getCollection(ConfigDB.DB_URL, ConfigDB.DB_USERNAME, ConfigDB.DB_PASSWORD);
	}

	///////////////// CONSULTAR TODOS LOS PRODUCTOS //////////////////
	public static List<Libro> consultarProductos()
			throws ClassNotFoundException, IllegalAccessException, InstantiationException, XMLDBException {

		Collection coleccion = null;
		List<Libro> listaLibros = null;

		try {

			coleccion = conectar();

			XPathQueryService servicio = (XPathQueryService) coleccion.getService("XPathQueryService", "1.0");
			String consulta = "for $lib in /libros/libro order by $lib/agno descending return $lib";
			ResourceSet resultados = servicio.query(consulta);
			ResourceIterator iterador = resultados.getIterator();

			listaLibros = new ArrayList<>();

			while (iterador.hasMoreResources()) {
				Resource recurso = iterador.nextResource();
				String productoString = (String) recurso.getContent();
				Libro libroTemp = new Libro(productoString);
				listaLibros.add(libroTemp);
			}

		} finally {
			if (coleccion != null && coleccion.isOpen()) {
				coleccion.close();
			}
		}

		return listaLibros;
	}

	////////////////// CONSULTAR SOCIO POR DNI //////////////////////
	public static Socio consultarSocioPorDNI(String dni)
			throws ClassNotFoundException, IllegalAccessException, InstantiationException, XMLDBException {

		Socio socio = null;
		Collection coleccion = null;
		try {

			coleccion = conectar();

			XPathQueryService servicio = (XPathQueryService) coleccion.getService("XPathQueryService", "1.0");

			String consulta = "for $soc in /socios/socio where $soc/dni = '" + dni + "' return $soc";
			ResourceSet resultados = servicio.query(consulta);

			ResourceIterator iterador = resultados.getIterator();
			if (iterador.hasMoreResources()) {
				Resource recurso = iterador.nextResource();
				String socioString = (String) recurso.getContent();
				socio = new Socio(socioString);
			}
		} finally {
			if (coleccion != null && coleccion.isOpen()) {
				coleccion.close();
			}
		}
		return socio;
	}

	////////////////// INSERTAR SOCIO //////////////////////
	public static boolean insertarSocio(String dni, String nombre, String localidad, String telefono, String correo)
			throws ClassNotFoundException, IllegalAccessException, InstantiationException, XMLDBException {

		boolean socioInsertado = false;
		Collection coleccion = null;
		try {

			coleccion = conectar();

			XPathQueryService servicio = (XPathQueryService) coleccion.getService("XPathQueryService", "1.0");

			String sentenciaInsertarSocio = "update insert " + "<socio>" + "<dni>" + dni + "</dni>" + "<nombre>"
					+ nombre + "</nombre>" + "<localidad>" + localidad + "</localidad>" + "<telefono>" + telefono
					+ "</telefono>" + "<correo>" + correo + "</correo>" + "</socio> " + "into /socios";

			ResourceSet resultados = servicio.query(sentenciaInsertarSocio);

			socioInsertado = true;

		} finally {
			if (coleccion != null && coleccion.isOpen()) {
				coleccion.close();
			}
		}
		return socioInsertado;
	}

	///////////////// CONSULTAR PRESTAMOS POR DNI //////////////////
	public static List<Prestamo> consultarPrestamosPorDNI(String dni)
			throws ClassNotFoundException, IllegalAccessException, InstantiationException, XMLDBException {

		Collection coleccion = null;
		List<Prestamo> listaPrestamos = null;

		try {

			coleccion = conectar();

			XPathQueryService servicio = (XPathQueryService) coleccion.getService("XPathQueryService", "1.0");
			String consulta = "for $pres in /prestamos/prestamo where $pres/dni_socio = '" + dni + "' return $pres";
			ResourceSet resultados = servicio.query(consulta);
			ResourceIterator iterador = resultados.getIterator();

			listaPrestamos = new ArrayList<>();

			while (iterador.hasMoreResources()) {
				Resource recurso = iterador.nextResource();
				String prestamoString = (String) recurso.getContent();
				Prestamo prestamoTemp = new Prestamo(prestamoString);
				listaPrestamos.add(prestamoTemp);
			}

		} finally {
			if (coleccion != null && coleccion.isOpen()) {
				coleccion.close();
			}
		}

		return listaPrestamos;
	}

	////////////////// ELIMINAR SOCIO //////////////////////
	public static boolean eliminarSocio(String dni)
			throws ClassNotFoundException, IllegalAccessException, InstantiationException, XMLDBException {

		boolean socioEliminado = false;

		Collection coleccion = null;
		try {

			coleccion = conectar();

			XPathQueryService servicio = (XPathQueryService) coleccion.getService("XPathQueryService", "1.0");

			Socio socioEliminar = consultarSocioPorDNI(dni);

			if (socioEliminar != null) {
				String sentenciaEliminarSocio = "update delete " + "/socios/socio[dni = '" + dni + "']";
				ResourceSet resultados = servicio.query(sentenciaEliminarSocio);
				socioEliminado = true;
			}

		} finally {
			if (coleccion != null && coleccion.isOpen()) {
				coleccion.close();
			}
		}

		return socioEliminado;
	}

}
