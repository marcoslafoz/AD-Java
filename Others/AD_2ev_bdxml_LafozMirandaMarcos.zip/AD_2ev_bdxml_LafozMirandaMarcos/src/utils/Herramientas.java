package utils;

public class Herramientas {
	/////////////// MOSTRAR MEN� ////////////////
	public static void mostrarMenu() {
		System.out.println("\nMen� de Opciones:");
		System.out.println("0) Salir del programa.");
		System.out.println("1) Consultar todos los libros.");
		System.out.println("2) Insertar un socio");
		System.out.println("3) Eliminar un socio");
	}
}
