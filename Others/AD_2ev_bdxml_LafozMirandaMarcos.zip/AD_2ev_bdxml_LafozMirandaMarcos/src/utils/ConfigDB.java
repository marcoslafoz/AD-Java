package utils;

public class ConfigDB {

	public static final String EXIST_DRIVER = "org.exist.xmldb.DatabaseImpl";
	public static final String DB_NAME = "biblioteca";
	public static final String DB_URL = "xmldb:exist://localhost:8080/exist/xmlrpc/db/" + DB_NAME;
	public static final String DB_USERNAME = "admin";
	public static final String DB_PASSWORD = "admin";
}
